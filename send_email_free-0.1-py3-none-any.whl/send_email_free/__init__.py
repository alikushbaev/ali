import smtplib
from email.mime.text import MIMEText
def send_email(message,password,sender,to,Subject):
    server = smtplib.SMTP("smtp.gmail.com",587)
    server.starttls()
    try:
        server.login(sender,password)
        msg = MIMEText(message)
        msg["Subject"] = Subject
        msg["To"] = to
        server.sendmail(sender,to,msg.as_string())
        print(f"send successful")
    except Exception as _ex:
        print(f"error:{_ex}")